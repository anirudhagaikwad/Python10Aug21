Project Name: Write a program to generate console base invoice (Mini Project     Duration - 3 days)
              -- Add products with price
              -- show product list
              -- generate invoice (bill)
Group Members: Namrata Jagtap(Leader)
               Gayatri Mhetre
               Vaishnavi Ghodake
               Ruchee Bansode
               Snehal Jawer

step 1: Create a database which name is product.
step 2: Create a table which name is cosmeticproduct.
step 3: Create a file which name is insert. In this file we add our available products name and products price.
step 4: Craete a new file which name is fetchall .In this file show our all cosmaticproducts
step 5: In fetch file we show our product list which is available in cosmeticproduct list.
step 6: Create a one more file for get bill recipt.
step 7:  *welcome to our shop*
        i)Then Enter your products which you want.
        ii)Then press Enter key.
        iii)Then you can get your bill recipt.
        
