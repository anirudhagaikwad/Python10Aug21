print("Creating Database=>\n")
import Database
print("\n\n\nCreating Table=>\n")
import Table
print("\n\n\nInserting Product=>\n")
import InsertProduct
print("\n\n\nCreating Bill =>\n")
import Bill