Project Name: Write a program to generate console base invoice ( Mini Project )
              -- Add products with price
              -- show product list
              -- generate invoice (bill)

Group Members: Farheensaba Shaikh (Leader)
               Tejas Sadafule
               Vinayak Konapure
               Yogesh Jindam
               Aryan Pawar

Software Requirement : Python Version 3
                       VS Code

step 1: Run the main.py file.
step 2: Enter your name.
step 3: Enter which product do you want to buy.
step 4: Then insert how many quantity do you want buy. 
step 5: Do you want some more product want to buy then type yes or no (Y/N).
step 6: Then input the percentage of discount for customer.
step 7: Genrate the invoice bill
step 8:  *Thankyou for shopping*
    