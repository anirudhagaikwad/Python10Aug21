import sys
import mysql.connector
from datetime import date


def exit():
    sys.exit()

def veg():
    try:
        mydb = mysql.connector.connect(host='localhost',user ='root', password ='root', port='3306', database ='desieatery')
        mycursor = mydb.cursor()
        query = "SELECT * from veg"
        mycursor.execute(query)
        tdata = mycursor.fetchall()
        print("Id ", "     Price ", "   Dish name  ")
        for row in tdata:
            print(row[0], "\t", "", row[2], "\t  ", row[1])
        mydb.commit()
    except:
        print("no veg items available")

def nonveg():
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', password='root', port='3306',
                                       database='desieatery')
        mycursor = mydb.cursor()
        query = "SELECT * from nonveg"
        mycursor.execute(query)
        tdata = mycursor.fetchall()
        print("Id ", "     Price ", "   Dish name  ")
        for row in tdata:
            print(row[0], "\t", "", row[2], "\t  ", row[1])
        mydb.commit()
    except:
        print("no veg items available")


def database():
    try:
        mydb = mysql.connector.connect(host='localhost',user ='root', password ='root', port='3306', database ='desieatery')
        mycursor = mydb.cursor()
        print("Select: \n 1. Veg Items \n 2. Nonveg items \n 3. Both Menu")
        ch = int(input("Enter your choice:   "))
        if ch == 4:
            sys.exit()
        while (ch != 4):
            if ch == 1:
                veg()
                mydb.commit()
                break
            elif ch == 2:
                nonveg()
                mydb.commit()
                break
            elif ch == 3:
                veg()
                nonveg()
                mydb.commit()
                break
    except:
        print("Menu not available")


def ItemAdd():
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', password='root', port='3306', database='desieatery')
        mycursor = mydb.cursor()
        orderId = input("Enter order id:  ")
        database()
        itemId = input("Enter item id: ")
        itemName = input("Enter Item name: ")
        quantity = input("Enter Quantity: ")
        rate = input("Enter rate: ")
        query = "insert into selecteditems (iid, iname, quantity, rate, orderId) values (%s, %s, %s, %s, %s)"
        val = (itemId, itemName, quantity, rate, orderId)
        mycursor.execute(query,val)
        mydb.commit()
        print("Item add successfully")
    except:
        print("Item not added")





def Item():
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', password='root', port='3306', database='desieatery')
        mycursor = mydb.cursor()
        print("\nWelcome to DesiEatery\n")
        print("Add Items:")
        ItemAdd()
        mydb.commit()
        print("Order added")

    except:
        print("Order added")

def Display():
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', password='root', port='3306', database='desieatery')
        mycursor = mydb.cursor()
        query = "Select iname, quantity, rate, (quantity*rate) AS amount from selecteditems where orderId = 1 "
        mycursor.execute(query)
        tdata = mycursor.fetchall()
        print("Quantity \t \t", "   Rate  \t\t\t", "  Amount  \t\t\t" , "Item \t\t ")
        for row in tdata:
            print(row[1], "\t\t \t", "\t\t",     row[2],  "  \t\t\t  ","\t",   row[3], "\t\t\t", row[0])
        mydb.commit()
    except:
        print("No data to display")

def Sum():
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', password='root', port='3306',database='desieatery')
        mycursor = mydb.cursor()
        query = "Select SUM(rate*quantity) AS TotalAmount from selecteditems where orderId = 1"
        mycursor.execute(query)
        tdata = mycursor.fetchall()
        for row in tdata:
            print("\n\1t\t\t\t\t\t\t\t\t\t",row[0],"\t\t\t Total Amount")
        mydb.commit()

    except:
        print("Exception in calculating")







Item()
cashierName = input("Enter Cashier name : ")
today = date.today()
print("**********************************************************************")
print("\t\t\t\t\t\t\t\tDesi Eatery")
print("\t\t\t\t12,Linking rd,Bandra west,Mumbai,400050")
print("\t\t\t\t\t\tTiming:9.00 am to 11.00 pm")
print("\t\t \t\t\t\t Contact no:9876543210")
print("\t\t\t\t\t\t\t\tTax Invoice")
print("\t\t\t\tCashier:",cashierName,"\t\t\tDate: ",today,"\n")
Display()
Sum()
print("\t\t\t\t\t\tThank you for your visit!")
print("\t\t\t\t\t\t\t  Have  nice day!")
print("\t\t\t\t\tFollow us on instagram @desi_eatery")
