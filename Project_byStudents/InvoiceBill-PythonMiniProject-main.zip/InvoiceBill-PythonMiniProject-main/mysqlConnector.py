import mysql.connector

try:
    mydb = mysql.connector.connect(host='localhost',user ='root', password ='root', port='3306', database ='desieatery')
    #mycursor = mydb.cursor();
    print("connection success",mydb.database)
except:
    print("unsucessful")