import mysql.connector

try:
    mydb = mysql.connector.connect(host='localhost',user ='root', password ='root', port='3306', database ='desieatery')
    mycursor = mydb.cursor()
    query="""insert into veg(vid,vname,vprice) values (%s,%s, %s)"""
    vegItem= [(101,'Butter paneer',100),
                    (102,'Shahi paneer',100),
                    (103,'Cholee masala',60),
                    (104,'Dal makhani',50),
                    (105,'Dal Tadka',40)]
    mycursor.executemany(query,vegItem)

    query1 = """insert into nonveg(nvid,nvname,nvprice) values (%s,%s, %s)"""
    nonvegItem = [(201,'Butter boneless chicken',120),
                    (202,'Chicken curry',80),
                    (203,'Chicken mughlai',120),
                    (204,'Anda curry',60),
                    (205,'Chicken Biryani',100)]
    mycursor.executemany(query1, nonvegItem)

    print("execute query")

    mydb.commit()
except:
    print("unsuccessfull")