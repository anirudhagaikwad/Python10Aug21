import mysql.connector

try:
    mydb = mysql.connector.connect(host='localhost', user='root', password='root', port='3306', database='desieatery')
    mycursor = mydb.cursor()
    mycursor.execute("create table veg(vid int(4),vname varchar(40),vprice int(6))")
    mycursor.execute("create table nonveg(nvid int(4),nvname varchar(40),nvprice int(6))")
    mycursor.execute("create table selecteditems(iid int(4), iname varchar(40), quantity int(2), rate int(6)) ")


    print("tables created succesfully",)
    mycursor.execute("show tables")

except:
    print("unsucessful")

