# Restaurant Invoice Bill

## General Information
Console based application to calculate the invoice bill at a restaurant 

## Technologies Used
UI layer tech. : PyCharm, MySQL Workbench

Logic layer tech. : Python programming language

Database Layer tech. : MySQL Database
## Features
List the ready features here:
* Easy to understand.
* Makes it easier to prepare the bill
## Setup
Project requirements/dependencies:
* Python version 3
* MySQLdb (pip install mysql-connector-python)

Just download the files or clone the project in your device and install the dependencies and we are good to go.
## How to access the application
- Directly run the main.py file in PyCharm
- Initially the user needs to add order id
- Then Select menu to display: 
 1. Veg Items 
 2. Nonveg items 
 3. Both Menu
- Enter the item id,name,quantity,rate per item
- Enter the cashier name
- Now,the invoice bill is generated with the total amount
- If you want to add more items to the previous order just enter the respective order number and the items will be added to the respective order.


## Acknowledgements
Give credit here.
This project was based on python tutorial.
Many thanks to My team.





